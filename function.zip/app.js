const axios = require('axios');
const AWS = require('aws-sdk');

const docClient = new AWS.DynamoDB.DocumentClient();
const getProductByIdURL = 'https://green-dostavka.by/api/v1/products/';

const params = (Item) => ({
  TableName : 'greenProductsDB',
  Item,
});

const createItem = async (product) => {
  try {
    await docClient.put(params).promise();
  } catch (err) {
    return err;
  }
};

const getProductById = async (productID) => {
  try {
    const response = await axios.get(`${getProductByIdURL}${productID}?storeId=2`);

    if (response.status === 200) {
      const { description, barcodes, title } = response.data;

      return !(description || barcodes)
          ? null
          : {
            title,
            barcode: barcodes[0]?.code,
            description,
          };
    }
  } catch (e) {
    console.error(e);
  }
};

export const parserHandler = async (event) => {
  try {
    console.time('Time');
    for (let i = 0; i <= 100; i += 100) {
      const url =`https://green-dostavka.by/api/v1/products?storeId=2&skip=${i}`;

      const response = await axios.get(url);

      if (response.status !== 200) {
        continue;
      }

      response.data.items.map( async ({id: productID}) => i{
        const product = await getProductById(productID);

        createItem(product);
      });

    }
    console.timeEnd('Time');
  }
  catch (error) {
    console.log(error);
  }
};