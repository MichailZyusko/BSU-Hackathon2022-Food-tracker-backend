export default async (req, res, next) => {
  res.send('Helloq World!');
};
